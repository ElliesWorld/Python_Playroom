Programming Quiz - Portable Version
===================================

This is a portable version of the Programming Quiz application.

To run:
1. Double-click programming_quiz.exe
2. Start learning!

Features:
- Interactive Python, C++, and C programming quizzes
- Comprehensive reference books for each language
- Beautiful 3D question mark button for quick book access
- Progress tracking and level unlocking

No installation required - all dependencies are included.

Enjoy your programming journey!
